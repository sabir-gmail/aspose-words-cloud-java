<!DOCTYPE html>

<html lang="en" class="devsite wf-opensans-n4-active wf-active"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={xpid:"VwQOVFBRGwIIXVVVDgU="};window.NREUM||(NREUM={}),__nr_require=function(t,e,n){function r(n){if(!e[n]){var o=e[n]={exports:{}};t[n][0].call(o.exports,function(e){var o=t[n][1][e];return r(o||e)},o,o.exports)}return e[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(t,e,n){function r(t){try{s.console&&console.log(t)}catch(e){}}var o,i=t("ee"),a=t(11),s={};try{o=localStorage.getItem("__nr_flags").split(","),console&&"function"==typeof console.log&&(s.console=!0,-1!==o.indexOf("dev")&&(s.dev=!0),-1!==o.indexOf("nr_dev")&&(s.nrDev=!0))}catch(c){}s.nrDev&&i.on("internal-error",function(t){r(t.stack)}),s.dev&&i.on("fn-err",function(t,e,n){r(n.stack)}),s.dev&&(r("NR AGENT IN DEVELOPMENT MODE"),r("flags: "+a(s,function(t,e){return t}).join(", ")))},{}],2:[function(t,e,n){function r(t,e,n,r,o){try{d?d-=1:i("err",[o||new UncaughtException(t,e,n)])}catch(s){try{i("ierr",[s,(new Date).getTime(),!0])}catch(c){}}return"function"==typeof f?f.apply(this,a(arguments)):!1}function UncaughtException(t,e,n){this.message=t||"Uncaught error with no additional information",this.sourceURL=e,this.line=n}function o(t){i("err",[t,(new Date).getTime()])}var i=t("handle"),a=t(12),s=t("ee"),c=t("loader"),f=window.onerror,u=!1,d=0;c.features.err=!0,t(1),window.onerror=r;try{throw new Error}catch(l){"stack"in l&&(t(5),t(4),"addEventListener"in window&&t(3),c.xhrWrappable&&t(6),u=!0)}s.on("fn-start",function(t,e,n){u&&(d+=1)}),s.on("fn-err",function(t,e,n){u&&(this.thrown=!0,o(n))}),s.on("fn-end",function(){u&&!this.thrown&&d>0&&(d-=1)}),s.on("internal-error",function(t){i("ierr",[t,(new Date).getTime(),!0])})},{}],3:[function(t,e,n){function r(t){for(var e=t;e&&!e.hasOwnProperty(u);)e=Object.getPrototypeOf(e);e&&o(e)}function o(t){s.inPlace(t,[u,d],"-",i)}function i(t,e){return t[1]}var a=t("ee").get("events"),s=t(13)(a),c=t("gos"),f=XMLHttpRequest,u="addEventListener",d="removeEventListener";e.exports=a,"getPrototypeOf"in Object?(r(document),r(window),r(f.prototype)):f.prototype.hasOwnProperty(u)&&(o(window),o(f.prototype)),a.on(u+"-start",function(t,e){if(t[1]){var n=t[1];if("function"==typeof n){var r=c(n,"nr@wrapped",function(){return s(n,"fn-",null,n.name||"anonymous")});this.wrapped=t[1]=r}else"function"==typeof n.handleEvent&&s.inPlace(n,["handleEvent"],"fn-")}}),a.on(d+"-start",function(t){var e=this.wrapped;e&&(t[1]=e)})},{}],4:[function(t,e,n){var r=t("ee").get("raf"),o=t(13)(r);e.exports=r,o.inPlace(window,["requestAnimationFrame","mozRequestAnimationFrame","webkitRequestAnimationFrame","msRequestAnimationFrame"],"raf-"),r.on("raf-start",function(t){t[0]=o(t[0],"fn-")})},{}],5:[function(t,e,n){function r(t,e,n){t[0]=a(t[0],"fn-",null,n)}function o(t,e,n){this.method=n,this.timerDuration="number"==typeof t[1]?t[1]:0,t[0]=a(t[0],"fn-",this,n)}var i=t("ee").get("timer"),a=t(13)(i);e.exports=i,a.inPlace(window,["setTimeout","setImmediate"],"setTimer-"),a.inPlace(window,["setInterval"],"setInterval-"),a.inPlace(window,["clearTimeout","clearImmediate"],"clearTimeout-"),i.on("setInterval-start",r),i.on("setTimer-start",o)},{}],6:[function(t,e,n){function r(t,e){d.inPlace(e,["onreadystatechange"],"fn-",s)}function o(){var t=this,e=u.context(t);t.readyState>3&&!e.resolved&&(e.resolved=!0,u.emit("xhr-resolved",[],t)),d.inPlace(t,v,"fn-",s)}function i(t){y.push(t),h&&(g=-g,x.data=g)}function a(){for(var t=0;t<y.length;t++)r([],y[t]);y.length&&(y=[])}function s(t,e){return e}function c(t,e){for(var n in t)e[n]=t[n];return e}t(3);var f=t("ee"),u=f.get("xhr"),d=t(13)(u),l=NREUM.o,p=l.XHR,h=l.MO,m="readystatechange",v=["onload","onerror","onabort","onloadstart","onloadend","onprogress","ontimeout"],y=[];e.exports=u;var w=window.XMLHttpRequest=function(t){var e=new p(t);try{u.emit("new-xhr",[e],e),e.addEventListener(m,o,!1)}catch(n){try{u.emit("internal-error",[n])}catch(r){}}return e};if(c(p,w),w.prototype=p.prototype,d.inPlace(w.prototype,["open","send"],"-xhr-",s),u.on("send-xhr-start",function(t,e){r(t,e),i(e)}),u.on("open-xhr-start",r),h){var g=1,x=document.createTextNode(g);new h(a).observe(x,{characterData:!0})}else f.on("fn-end",function(t){t[0]&&t[0].type===m||a()})},{}],7:[function(t,e,n){function r(t){var e=this.params,n=this.metrics;if(!this.ended){this.ended=!0;for(var r=0;l>r;r++)t.removeEventListener(d[r],this.listener,!1);if(!e.aborted){if(n.duration=(new Date).getTime()-this.startTime,4===t.readyState){e.status=t.status;var i=o(t,this.lastSize);if(i&&(n.rxSize=i),this.sameOrigin){var a=t.getResponseHeader("X-NewRelic-App-Data");a&&(e.cat=a.split(", ").pop())}}else e.status=0;n.cbTime=this.cbTime,u.emit("xhr-done",[t],t),c("xhr",[e,n,this.startTime])}}}function o(t,e){var n=t.responseType;if("json"===n&&null!==e)return e;var r="arraybuffer"===n||"blob"===n||"json"===n?t.response:t.responseText;return i(r)}function i(t){if("string"==typeof t&&t.length)return t.length;if("object"==typeof t){if("undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer&&t.byteLength)return t.byteLength;if("undefined"!=typeof Blob&&t instanceof Blob&&t.size)return t.size;if(!("undefined"!=typeof FormData&&t instanceof FormData))try{return JSON.stringify(t).length}catch(e){return}}}function a(t,e){var n=f(e),r=t.params;r.host=n.hostname+":"+n.port,r.pathname=n.pathname,t.sameOrigin=n.sameOrigin}var s=t("loader");if(s.xhrWrappable){var c=t("handle"),f=t(8),u=t("ee"),d=["load","error","abort","timeout"],l=d.length,p=t("id"),h=t(10),m=window.XMLHttpRequest;s.features.xhr=!0,t(6),u.on("new-xhr",function(t){var e=this;e.totalCbs=0,e.called=0,e.cbTime=0,e.end=r,e.ended=!1,e.xhrGuids={},e.lastSize=null,h&&(h>34||10>h)||window.opera||t.addEventListener("progress",function(t){e.lastSize=t.loaded},!1)}),u.on("open-xhr-start",function(t){this.params={method:t[0]},a(this,t[1]),this.metrics={}}),u.on("open-xhr-end",function(t,e){"loader_config"in NREUM&&"xpid"in NREUM.loader_config&&this.sameOrigin&&e.setRequestHeader("X-NewRelic-ID",NREUM.loader_config.xpid)}),u.on("send-xhr-start",function(t,e){var n=this.metrics,r=t[0],o=this;if(n&&r){var a=i(r);a&&(n.txSize=a)}this.startTime=(new Date).getTime(),this.listener=function(t){try{"abort"===t.type&&(o.params.aborted=!0),("load"!==t.type||o.called===o.totalCbs&&(o.onloadCalled||"function"!=typeof e.onload))&&o.end(e)}catch(n){try{u.emit("internal-error",[n])}catch(r){}}};for(var s=0;l>s;s++)e.addEventListener(d[s],this.listener,!1)}),u.on("xhr-cb-time",function(t,e,n){this.cbTime+=t,e?this.onloadCalled=!0:this.called+=1,this.called!==this.totalCbs||!this.onloadCalled&&"function"==typeof n.onload||this.end(n)}),u.on("xhr-load-added",function(t,e){var n=""+p(t)+!!e;this.xhrGuids&&!this.xhrGuids[n]&&(this.xhrGuids[n]=!0,this.totalCbs+=1)}),u.on("xhr-load-removed",function(t,e){var n=""+p(t)+!!e;this.xhrGuids&&this.xhrGuids[n]&&(delete this.xhrGuids[n],this.totalCbs-=1)}),u.on("addEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&u.emit("xhr-load-added",[t[1],t[2]],e)}),u.on("removeEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&u.emit("xhr-load-removed",[t[1],t[2]],e)}),u.on("fn-start",function(t,e,n){e instanceof m&&("onload"===n&&(this.onload=!0),("load"===(t[0]&&t[0].type)||this.onload)&&(this.xhrCbStart=(new Date).getTime()))}),u.on("fn-end",function(t,e){this.xhrCbStart&&u.emit("xhr-cb-time",[(new Date).getTime()-this.xhrCbStart,this.onload,e],e)})}},{}],8:[function(t,e,n){e.exports=function(t){var e=document.createElement("a"),n=window.location,r={};e.href=t,r.port=e.port;var o=e.href.split("://");!r.port&&o[1]&&(r.port=o[1].split("/")[0].split("@").pop().split(":")[1]),r.port&&"0"!==r.port||(r.port="https"===o[0]?"443":"80"),r.hostname=e.hostname||n.hostname,r.pathname=e.pathname,r.protocol=o[0],"/"!==r.pathname.charAt(0)&&(r.pathname="/"+r.pathname);var i=!e.protocol||":"===e.protocol||e.protocol===n.protocol,a=e.hostname===document.domain&&e.port===n.port;return r.sameOrigin=i&&(!e.hostname||a),r}},{}],9:[function(t,e,n){function r(t,e){return function(){o(t,[(new Date).getTime()].concat(a(arguments)),null,e)}}var o=t("handle"),i=t(11),a=t(12);"undefined"==typeof window.newrelic&&(newrelic=NREUM);var s=["setPageViewName","addPageAction","setCustomAttribute","finished","addToTrace","inlineHit"],c=["addPageAction"],f="api-";i(s,function(t,e){newrelic[e]=r(f+e,"api")}),i(c,function(t,e){newrelic[e]=r(f+e)}),e.exports=newrelic,newrelic.noticeError=function(t){"string"==typeof t&&(t=new Error(t)),o("err",[t,(new Date).getTime()])}},{}],10:[function(t,e,n){var r=0,o=navigator.userAgent.match(/Firefox[\/\s](\d+\.\d+)/);o&&(r=+o[1]),e.exports=r},{}],11:[function(t,e,n){function r(t,e){var n=[],r="",i=0;for(r in t)o.call(t,r)&&(n[i]=e(r,t[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],12:[function(t,e,n){function r(t,e,n){e||(e=0),"undefined"==typeof n&&(n=t?t.length:0);for(var r=-1,o=n-e||0,i=Array(0>o?0:o);++r<o;)i[r]=t[e+r];return i}e.exports=r},{}],13:[function(t,e,n){function r(t){return!(t&&"function"==typeof t&&t.apply&&!t[a])}var o=t("ee"),i=t(12),a="nr@original",s=Object.prototype.hasOwnProperty,c=!1;e.exports=function(t){function e(t,e,n,o){function nrWrapper(){var r,a,s,c;try{a=this,r=i(arguments),s="function"==typeof n?n(r,a):n||{}}catch(u){d([u,"",[r,a,o],s])}f(e+"start",[r,a,o],s);try{return c=t.apply(a,r)}catch(l){throw f(e+"err",[r,a,l],s),l}finally{f(e+"end",[r,a,c],s)}}return r(t)?t:(e||(e=""),nrWrapper[a]=t,u(t,nrWrapper),nrWrapper)}function n(t,n,o,i){o||(o="");var a,s,c,f="-"===o.charAt(0);for(c=0;c<n.length;c++)s=n[c],a=t[s],r(a)||(t[s]=e(a,f?s+o:o,i,s))}function f(e,n,r){if(!c){c=!0;try{t.emit(e,n,r)}catch(o){d([o,e,n,r])}c=!1}}function u(t,e){if(Object.defineProperty&&Object.keys)try{var n=Object.keys(t);return n.forEach(function(n){Object.defineProperty(e,n,{get:function(){return t[n]},set:function(e){return t[n]=e,e}})}),e}catch(r){d([r])}for(var o in t)s.call(t,o)&&(e[o]=t[o]);return e}function d(e){try{t.emit("internal-error",e)}catch(n){}}return t||(t=o),e.inPlace=n,e.flag=a,e}},{}],ee:[function(t,e,n){function r(){}function o(t){function e(t){return t&&t instanceof r?t:t?s(t,a,i):i()}function n(n,r,o){t&&t(n,r,o);for(var i=e(o),a=l(n),s=a.length,c=0;s>c;c++)a[c].apply(i,r);var u=f[v[n]];return u&&u.push([y,n,r,i]),i}function d(t,e){m[t]=l(t).concat(e)}function l(t){return m[t]||[]}function p(t){return u[t]=u[t]||o(n)}function h(t,e){c(t,function(t,n){e=e||"feature",v[n]=e,e in f||(f[e]=[])})}var m={},v={},y={on:d,emit:n,get:p,listeners:l,context:e,buffer:h};return y}function i(){return new r}var a="nr@context",s=t("gos"),c=t(11),f={},u={},d=e.exports=o();d.backlog=f},{}],gos:[function(t,e,n){function r(t,e,n){if(o.call(t,e))return t[e];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,e,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return t[e]=r,r}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],handle:[function(t,e,n){function r(t,e,n,r){o.buffer([t],r),o.emit(t,e,n)}var o=t("ee").get("handle");e.exports=r,r.ee=o},{}],id:[function(t,e,n){function r(t){var e=typeof t;return!t||"object"!==e&&"function"!==e?-1:t===window?0:a(t,i,function(){return o++})}var o=1,i="nr@id",a=t("gos");e.exports=r},{}],loader:[function(t,e,n){function r(){if(!m++){var t=h.info=NREUM.info,e=u.getElementsByTagName("script")[0];if(t&&t.licenseKey&&t.applicationID&&e){c(l,function(e,n){t[e]||(t[e]=n)});var n="https"===d.split(":")[0]||t.sslForHttp;h.proto=n?"https://":"http://",s("mark",["onload",a()],null,"api");var r=u.createElement("script");r.src=h.proto+t.agent,e.parentNode.insertBefore(r,e)}}}function o(){"complete"===u.readyState&&i()}function i(){s("mark",["domContent",a()],null,"api")}function a(){return(new Date).getTime()}var s=t("handle"),c=t(11),f=window,u=f.document;NREUM.o={ST:setTimeout,CT:clearTimeout,XHR:f.XMLHttpRequest,REQ:f.Request,EV:f.Event,PR:f.Promise,MO:f.MutationObserver},t(9);var d=""+location,l={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-918.min.js"},p=window.XMLHttpRequest&&XMLHttpRequest.prototype&&XMLHttpRequest.prototype.addEventListener&&!/CriOS/.test(navigator.userAgent),h=e.exports={offset:a(),origin:d,features:{},xhrWrappable:p};u.addEventListener?(u.addEventListener("DOMContentLoaded",i,!1),f.addEventListener("load",r,!1)):(u.attachEvent("onreadystatechange",o),f.attachEvent("onload",r)),s("mark",["firstbyte",a()],null,"api");var m=0},{}]},{},["loader",2,7]);</script>
    <meta charset="utf-8">
    <script src="/intl/en/developer/assets/script_head.js"></script>
    <link rel="stylesheet" type="text/css" href="/intl/en/developer/assets/screen.css">
    
    <link rel="shortcut icon" href="/sites/all/themes/sketchup/images/favicon.ico">
    
    
    <script src="/intl/en/developer/assets/jquery.min.js"></script>
    <script id="jqueryui" src="/intl/en/developer/assets/jquery-ui.min.js"></script>
    <script src="/intl/en/developer/assets/jsapi.js"></script>
    <script>
      google.load('visualization', '1', {packages: ['table']});
    </script><script src="/intl/en/developer/assets/saved_resource" type="text/javascript"></script><script src="/intl/en/developer/assets/format+en,default,table.I.js" type="text/javascript"></script><style>.a-b-c{position:relative;display:-moz-inline-box;display:inline-block}* html .a-b-c,*:first-child+html .a-b-c{display:inline}.a-d-e{margin:2px;border:0;padding:0;font-family:Arial,sans-serif;color:#000;background:#ddd url(//ssl.gstatic.com/editor/button-bg.png) repeat-x top left;text-decoration:none;list-style:none;vertical-align:middle;cursor:default;outline:none}.a-d-e-f-g,.a-d-e-h-g{border-style:solid;border-color:#aaa;vertical-align:top}.a-d-e-f-g{margin:0;border-width:1px 0;padding:0}.a-d-e-h-g{-moz-box-orient:vertical;margin:0 -1px;border-width:0 1px;padding:3px 4px;white-space:nowrap}* html .a-d-e-h-g{left:-1px}* html .a-d-e-i .a-d-e-f-g{left:-1px}* html .a-d-e-i .a-d-e-h-g{right:auto}*:first-child+html .a-d-e-h-g{left:-1px}*:first-child+html .a-d-e-i .a-d-e-h-g{left:1px}::root .a-d-e,::root .a-d-e-f-g{line-height:0}::root .a-d-e-h-g{line-height:normal}.a-d-e-j{background-image:none!important;opacity:.3;-moz-opacity:.3;filter:alpha(opacity=30)}.a-d-e-j .a-d-e-f-g,.a-d-e-j .a-d-e-h-g{color:#333!important;border-color:#999!important}* html .a-d-e-j,*:first-child+html .a-d-e-j{margin:2px 1px!important;padding:0 1px!important}.a-d-e-k .a-d-e-f-g,.a-d-e-k .a-d-e-h-g{border-color:#9cf #69e #69e #7af!important}.a-d-e-l,.a-d-e-m{background-color:#bbb;background-position:bottom left}.a-d-e-n .a-d-e-f-g,.a-d-e-n .a-d-e-h-g{border-color:orange}.a-d-e-o-p,.a-d-e-o-p .a-d-e-f-g,.a-d-e-o-p .a-d-e-h-g{margin-right:0}.a-d-e-o-q,.a-d-e-o-q .a-d-e-f-g{margin-left:0}.a-d-e-o-q .a-d-e-h-g{margin-left:0;border-left:1px solid #fff}.a-d-e-o-q.a-d-e-m .a-d-e-h-g{border-left:1px solid #ddd}* html .a-d-e-o-q .a-d-e-h-g,*:first-child+html .a-d-e-o-q .a-d-e-h-g{left:0}.a-r-e{position:relative;margin:2px;border:1px solid #000;padding:2px 6px;font:normal 13px "Trebuchet MS",Tahoma,Arial,sans-serif;color:#fff;background-color:#8c2425;cursor:pointer;outline:none}.a-r-e-j{border-color:#888;color:#888;background-color:#ccc;cursor:default}.a-r-e-k{border-color:#8c2425;color:#8c2425;background-color:#eaa4a5}.a-r-e-l,.a-r-e-s,.a-r-e-m{border-color:#5b4169;color:#5b4169;background-color:#d1a8ea}.a-r-e-n{border-color:#5b4169}.a-r-e-o-p{margin-right:0}.a-r-e-o-q{margin-left:0;border-left:none}.a-e{color:#036;border-color:#036;background-color:#69c}.a-e-j{border-color:#333;color:#333;background-color:#999}.a-e-k{color:#369;border-color:#369;background-color:#9cf}.a-e-l{color:#69c;border-color:#69c}</style><link href="/intl/en/developer/assets/table.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/intl/en/developer/assets/api.js"></script>
    <!--[if lt IE 9]>
    <script src="/_static/js/html5shim/html5.js"></script>
    <![endif]-->
    <!--[if IE]>
      <style>
      #sketchup-toc {
        position: relative;
        left: -40px;
        width: 200px;
      }

      body {
        overflow: visible;
      }
      </style>
    <![endif]-->
    
    <script>
      google.load('search', '1', {language : 'en'});
    </script><script src="/intl/en/developer/assets/saved_resource(1)" type="text/javascript"></script><script src="/intl/en/developer/assets/default+en.I.js" type="text/javascript"></script>
    

    
  <script type="text/javascript">
    var contentTimer = new window.jstiming.Timer();

    var ___gcfg = ___gcfg || {};
    ___gcfg.lang = 'en';
  </script>
  <script src="/intl/en/developer/assets/jquery-ui.min.js"></script>
  
  <title>SketchUp Ruby API</title>
  
  
  
    
    
    <link href="/intl/en/developer/css/local_extensions.css" rel="stylesheet" type="text/css"><link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans">
  


    
    

  </head>
  <body class="two-column docs">
    
	<div id="header">
		<h1>
		  <a href="http://www.sketchup.com"><img alt="Trimble SketchUp" src=
		  "http://www.sketchup.com/images/SU_Logo.png" width="190" height="40"></a>
		</h1>
	</div>
    
    

    <div id="gc-wrapper" itemscope="" itemtype="http://schema.org/Article">
      
      
      

      

      
      
      

      
      
      

      
      

      
      <div id="gc-main">
        
      
      
      <div id="gc-sidebar">
        

  


<a class="navitem-top" href="http://www.sketchup.com">Home</a>
<br/><a href="/intl/en/developer/index" class="navitem-top" style="color:#444;font-weight:bold">Developer Docs</a>

  <nav class="gc-toc"><ul id="sketchup-toc"><li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Introduction">Introduction</span><ul >
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Getting Started">Getting Started</span><ul >
<li class=""><a href="/intl/en/developer/docs/faq" data-title="FAQ"><span>FAQ</span></a></li>
<li class=""><a href="/intl/en/developer/docs/new_to_ruby" data-title="New to Ruby?"><span>New to Ruby?</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_console" data-title="The Ruby Console"><span>The Ruby Console</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_helloworld" data-title="Hello, World"><span>Hello, World</span></a></li>
<li class=""><a href="/intl/en/developer/docs/examples" data-title="Example Files"><span>Example Files</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Tutorials">Tutorials</span><ul ><li class=""><a href="/intl/en/developer/docs/tutorial_geometry" data-title="Creating Geometry"><span>Creating Geometry</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_camera" data-title="Moving the Camera"><span>Moving the Camera</span></a></li>
<li class=""><a href="/intl/en/developer/docs/loading" data-title="Loading Ruby Scripts"><span>Loading Ruby Scripts</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_attrreporting" data-title="Attribute Reporting"><span>Attribute Reporting</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_distributing" data-title="Distributing your Extension"><span>Distributing your Extension</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tutorial_licensing" data-title="Extension Licensing"><span>Extension Licensing</span></a></li>
</ul></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a>
  
  <span class="tlw-title tlw-control-title" data-title="Quick Reference">Quick Reference</span><ul id="quick-reference-nav"><li class=""><a href="/intl/en/developer/docs/classes" data-title="Class Index"><span>Class Index</span></a></li>
<li class=""><a href="/intl/en/developer/docs/methods" data-title="Method Index"><span>Method Index</span></a></li>
<li class=""><a href="/intl/en/developer/docs/utilities" data-title="Utilities"><span>Utilities</span></a></li>
</ul></li>

  
 <li class=""><a class="tlw-control tlw-expanded">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Object Reference">Object Reference</span><ul style=""><li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="App Level Classes">App Level Classes</span><ul ><li class=""><a href="/intl/en/developer/docs/ourdoc/sketchup" data-title="Sketchup"><span>Sketchup</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/model" data-title="Model"><span>Model</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/attributedictionary" data-title="Attribute Dictionary"><span>Attribute Dictionary</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/animation" data-title="Animation"><span>Animation</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/camera" data-title="Camera"><span>Camera</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/color" data-title="Color"><span>Color</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/extensionlicense" data-title="ExtensionLicense"><span>ExtensionLicense</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/sketchupextension" data-title="Extension"><span>Extension</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/importer" data-title="Importer"><span>Importer</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/languagehandler" data-title="LanguageHandler"><span>LanguageHandler</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/licensing" data-title="Licensing"><span>Licensing</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/optionsmanager" data-title="OptionsManager"><span>OptionsManager</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/optionsprovider" data-title="OptionsProvider"><span>OptionsProvider</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/set" data-title="Set"><span>Set</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/texturewriter" data-title="TextureWriter"><span>TextureWriter</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/view" data-title="View"><span>View</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/uvhelper" data-title="UVHelper"><span>UVHelper</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Entity Classes">Entity Classes</span><ul >
<li class=""><a href="/intl/en/developer/docs/ourdoc/entity" data-title="Entity"><span>Entity</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/drawingelement" data-title="Drawingelement"><span>Drawingelement</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/arccurve" data-title="ArcCurve"><span>ArcCurve</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/axes" data-title="Axes"><span>Axes</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/behavior" data-title="Behavior"><span>Behavior</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/classificationschema" data-title="ClassificationSchema"><span>ClassificationSchema</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/componentdefinition" data-title="ComponentDefinition"><span>ComponentDefinition</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/componentinstance" data-title="ComponentInstance"><span>ComponentInstance</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/constructionline" data-title="ConstructionLine"><span>ConstructionLine</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/constructionpoint" data-title="ConstructionPoint"><span>ConstructionPoint</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/curve" data-title="Curve"><span>Curve</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/dimension" data-title="Dimension"><span>Dimension</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/dimensionlinear" data-title="DimensionLinear"><span>DimensionLinear</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/dimensionradial" data-title="DimensionRadial"><span>DimensionRadial</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/edge" data-title="Edge"><span>Edge</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/edgeuse" data-title="EdgeUse"><span>EdgeUse</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/face" data-title="Face"><span>Face</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/group" data-title="Group"><span>Group</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/image" data-title="Image"><span>Image</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/material" data-title="Material"><span>Material</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/layer" data-title="Layer"><span>Layer</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/loop" data-title="Loop"><span>Loop</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/page" data-title="Page"><span>Page</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/sectionplane" data-title="SectionPlane"><span>SectionPlane</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/shadowinfo" data-title="ShadowInfo"><span>ShadowInfo</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/style" data-title="Style"><span>Style</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/text" data-title="Text"><span>Text</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/texture" data-title="Texture"><span>Texture</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Collection Classes">Collection Classes</span><ul ><li class=""><a href="/intl/en/developer/docs/ourdoc/attributedictionaries" data-title="AttributeDictionaries"><span>AttributeDictionaries</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/classifications" data-title="Classifications"><span>Classifications</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/definitionlist" data-title="DefinitionList"><span>DefinitionList</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/entities" data-title="Entities"><span>Entities</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/layers" data-title="Layers"><span>Layers</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/materials" data-title="Materials"><span>Materials</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/pages" data-title="Pages"><span>Pages</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/renderingoptions" data-title="RenderingOptions"><span>RenderingOptions</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/selection" data-title="Selection"><span>Selection</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/styles" data-title="Styles"><span>Styles</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/tools" data-title="Tools"><span>Tools</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-expanded">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Geom Classes">Geom Classes</span><ul style=""><li class=""><a href="/intl/en/developer/docs/ourdoc/geom" data-title="Geom"><span>Geom</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/boundingbox" data-title="Bounding Box"><span>Bounding Box</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/latlong" data-title="LatLong"><span>LatLong</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/point3d" data-title="Point3d"><span>Point3d</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/polygonmesh" data-title="PolygonMesh"><span>PolygonMesh</span></a></li>
<li class="active"><a href="/intl/en/developer/docs/ourdoc/vector3d" data-title="Vector3d"><span>Vector3d</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/vertex" data-title="Vertex"><span>Vertex</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/transformation" data-title="Transformation"><span>Transformation</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/utm" data-title="UTM"><span>UTM</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="UI Classes">UI Classes</span><ul ><li class=""><a href="/intl/en/developer/docs/ourdoc/ui" data-title="UI"><span>UI</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/command" data-title="Command"><span>Command</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/console" data-title="Console"><span>Console</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/inputpoint" data-title="InputPoint"><span>InputPoint</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/pickhelper" data-title="PickHelper"><span>PickHelper</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/menu" data-title="Menu"><span>Menu</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/tool" data-title="Tool"><span>Tool</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/toolbar" data-title="Toolbar"><span>Toolbar</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/webdialog" data-title="WebDialog"><span>WebDialog</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Observer Classes">Observer Classes</span><ul ><li class=""><a href="/intl/en/developer/docs/ourdoc/appobserver" data-title="AppObserver"><span>AppObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/definitionobserver" data-title="DefinitionObserver"><span>DefinitionObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/definitionsobserver" data-title="DefinitionsObserver"><span>DefinitionsObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/dimensionobserver" data-title="DimensionObserver"><span>DimensionObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/entitiesobserver" data-title="EntitiesObserver"><span>EntitiesObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/entityobserver" data-title="EntityObserver"><span>EntityObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/instanceobserver" data-title="InstanceObserver"><span>InstanceObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/layersobserver" data-title="LayersObserver"><span>LayersObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/materialsobserver" data-title="MaterialsObserver"><span>MaterialsObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/modelobserver" data-title="ModelObserver"><span>ModelObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/optionsproviderobserver" data-title="OptionsProviderObserver"><span>OptionsProviderObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/pagesobserver" data-title="PagesObserver"><span>PagesObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/renderingoptionsobserver" data-title="RenderingOptionsObserver"><span>RenderingOptionsObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/selectionobserver" data-title="SelectionObserver"><span>SelectionObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/shadowinfoobserver" data-title="ShadowInfoObserver"><span>ShadowInfoObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/toolsobserver" data-title="ToolsObserver"><span>ToolsObserver</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/viewobserver" data-title="ViewObserver"><span>ViewObserver</span></a></li>
</ul></li>
<li class=""><a class="tlw-control tlw-collapsed">&nbsp;</a><span class="tlw-title tlw-control-title" data-title="Core Ruby Classes">Core Ruby Classes</span><ul ><li class=""><a href="/intl/en/developer/docs/ourdoc/array" data-title="Array"><span>Array</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/length" data-title="Length"><span>Length</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/numeric" data-title="Numeric"><span>Numeric</span></a></li>
<li class=""><a href="/intl/en/developer/docs/ourdoc/string" data-title="String"><span>String</span></a></li>
</ul></li>
</ul></li>
<li class=""><a href="/intl/en/developer/docs/releases" data-title="Release Notes"><span>Release Notes</span></a></li>
<li class=""><a href="/intl/en/developer/docs/tos" data-title="Terms of Service"><span>Terms of Service</span></a></li>
</ul></nav>



      </div>
      

      <div id="gc-content">
        
        <div>

        
    <h1>Sketchup</h1>

<strong class="version">SketchUp 6.0+</strong>
  <h3 class="object_title">module</h3>
  <div class="parent_class"><b>Parent:&nbsp;</b>N/A</div>
<ul class="heading_list">
  <li><a href="#introduction"><b>Introduction</b></a></li>
  <li><a href="#methods"><b>Methods</b></a></li>
  <li>
    <table class="method_list">
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#active_model">active_model</a></td>
        <td class="method_list_cell"><a href="#get_datfile_info">get_datfile_info</a></td>
        <td class="method_list_cell"><a href="#register_extension">register_extension</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#add_observer">add_observer</a></td>
        <td class="method_list_cell"><a href="#get_i18ndatfile_info">get_i18ndatfile_info</a></td>
        <td class="method_list_cell"><a href="#register_importer">register_importer</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#app_name">app_name</a></td>
        <td class="method_list_cell"><a href="#get_locale">get_locale</a></td>
        <td class="method_list_cell"><a href="#remove_observer">remove_observer</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#break_edges=">break_edges=</a></td>
        <td class="method_list_cell"><a href="#get_resource_path">get_resource_path</a></td>
        <td class="method_list_cell"><a href="#require">require</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#break_edges?">break_edges?</a></td>
        <td class="method_list_cell"><a href="#get_shortcuts">get_shortcuts</a></td>
        <td class="method_list_cell"><a href="#save_thumbnail">save_thumbnail</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#create_texture_writer">create_texture_writer</a></td>
        <td class="method_list_cell"><a href="#install_from_archive">install_from_archive</a></td>
        <td class="method_list_cell"><a href="#send_action">send_action</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#debug_mode=">debug_mode=</a></td>
        <td class="method_list_cell"><a href="#is_64bit?">is_64bit?</a></td>
        <td class="method_list_cell"><a href="#set_status_text">set_status_text</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#debug_mode?">debug_mode?</a></td>
        <td class="method_list_cell"><a href="#is_online">is_online</a></td>
        <td class="method_list_cell"><a href="#status_text=">status_text=</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#display_name_from_action">display_name_from_action</a></td>
        <td class="method_list_cell"><a href="#is_pro?">is_pro?</a></td>
        <td class="method_list_cell"><a href="#temp_dir">temp_dir</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#extensions">extensions</a></td>
        <td class="method_list_cell"><a href="#is_valid_filename?">is_valid_filename?</a></td>
        <td class="method_list_cell"><a href="#template">template</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#file_new">file_new</a></td>
        <td class="method_list_cell"><a href="#load">load</a></td>
        <td class="method_list_cell"><a href="#template=">template=</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#find_support_file">find_support_file</a></td>
        <td class="method_list_cell"><a href="#open_file">open_file</a></td>
        <td class="method_list_cell"><a href="#template_dir">template_dir</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#find_support_files">find_support_files</a></td>
        <td class="method_list_cell"><a href="#os_language">os_language</a></td>
        <td class="method_list_cell"><a href="#undo">undo</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#fix_shadow_strings=">fix_shadow_strings=</a></td>
        <td class="method_list_cell"><a href="#parse_length">parse_length</a></td>
        <td class="method_list_cell"><a href="#vcb_label=">vcb_label=</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#fix_shadow_strings?">fix_shadow_strings?</a></td>
        <td class="method_list_cell"><a href="#platform">platform</a></td>
        <td class="method_list_cell"><a href="#vcb_value=">vcb_value=</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#format_angle">format_angle</a></td>
        <td class="method_list_cell"><a href="#plugins_disabled=">plugins_disabled=</a></td>
        <td class="method_list_cell"><a href="#version">version</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#format_area">format_area</a></td>
        <td class="method_list_cell"><a href="#plugins_disabled?">plugins_disabled?</a></td>
        <td class="method_list_cell"><a href="#version_number">version_number</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#format_degrees">format_degrees</a></td>
        <td class="method_list_cell"><a href="#quit">quit</a></td>
        <td class="method_list_cell"><a href="#write_default">write_default</a></td>
      </tr>
      <tr>
        <td class="method_list_empty_cell"/>
        <td class="method_list_cell"><a href="#format_length">format_length</a></td>
        <td class="method_list_cell"><a href="#read_default">read_default</a></td>
      </tr>
    </table>
  </li>
</ul>
<div class="clear"></div>
<h2 id="introduction">Introduction</h2>
<div class="introduction">
<p>
 The Sketchup module contains a number of important utility methods for use in
 your Ruby scripts. Many of the classes in the API are implemented beneath
 this module. You can think of the Sketchup module as the "root" of the
 application tree. Most ruby calls start from the currently active model, and
 this is accessed via the Sketchup.active_model method.</p>
<pre class="prettyprint">
     # Grab a handle to the currently active model (aka the one the user is
     # looking at in SketchUp.)
     model = Sketchup.active_model

     # Grab other handles to commonly used collections inside the model.
     entities = model.entities
     layers = model.layers
     materials = model.materials
     component_definitions = model.definitions
     selection = model.selection

     # Now that we have our handles, we can start pulling objects and making
     # method calls that are useful.
     first_entity = entities[0]
     UI.messagebox("First thing in your model is a " + first_entity.typename)

     number_materials = materials.length
     UI.messagebox("Your model has " + number_materials.to_s + " materials.")

     new_edge = entities.add_line( [0,0,0], [500,500,0])</pre><br class="clear"/>
<p></p>
<p></p>
</div><h2 id="methods">Methods</h2>
<dl class="apireference"> <dt id="active_model"><span class="itemname">Sketchup.active_model</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The active_model method returns the currently active SketchUp model. On the
 PC, this is the only model that one can have access to via the API, but
 Macintosh versions of SketchUp can have multiple models open at once, in
 which case the method will return the model that the user currently has
 focused.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>model</dt>
<dd>active model object if successful, false if
                      unsuccessful</dd></dl>
<pre class="prettyprint">
 model = Sketchup.active_model
 if (! model)
   UI.messagebox "Failure"
 else
   # code acting on the model
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="add_observer"><span class="itemname">Sketchup.add_observer</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The add_observer method is used to add an observer to the current object.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">observer</dt>
<dd>An observer.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.add_observer observer</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="app_name"><span class="itemname">Sketchup.app_name</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The app_name method is used to retrieve the current application name.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>name</dt>
<dd>the name of the application, either
                      "SketchUp Pro" or "SketchUp".
                      Note: For versions earlier than SketchUp8 M4
                      (Mac 8.0.15157 and Windows 8.0.15158) this function will
                      return "Google SketchUp Pro" or "Google SketchUp".</dd></dl>
<pre class="prettyprint">
 name = Sketchup.app_name</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="break_edges="><span class="itemname">Sketchup.break_edges=</span><span class="version">SketchUp 7.0+</span></dt>
<dd>
<p>
 The break_edges= method can be used to disable or enable the break edges
 feature. Break edges is the SketchUp 7 feature that automatically splits
 edges that the user draws which cross over one another.

<br/><br/> This feature is always on by default and cannot be disabled by the user
 via the user interface, but you can call this method to disable it. Be
 cautious in doing so, however, as the resulting model could then be altered
 when the user later draws lines into it with the break edges feature
 reactivated.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">enabled</dt>
<dd>If true, break edges will be turned on. If false, it will be deactivated.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>setting</dt>
<dd>true if break edges was turned on.</dd></dl>
<pre class="prettyprint">
 is_on = Sketchup.break_edges?</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="break_edges?"><span class="itemname">Sketchup.break_edges?</span><span class="version">SketchUp 7.0+</span></dt>
<dd>
<p>
 The break_edges? method indicates whether the break edges feature is
 currently turned on. Break edges is the SketchUp 7 feature that
 automatically splits edges that the user draws which cross over one another.
 This feature is always on by default and cannot be disabled by the user
 via the user interface.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>break_edges</dt>
<dd>true if the feature is on.</dd></dl>
<pre class="prettyprint">
 is_on = Sketchup.break_edges?</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="create_texture_writer"><span class="itemname">Sketchup.create_texture_writer</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The create_texture_writer method is used to create a <a href="texturewriter">TextureWriter</a> object.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>texturewriter</dt>
<dd>a texturewriter object if successful.</dd></dl>
<pre class="prettyprint">
 texturewriter = Sketchup.create_texture_writer</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="debug_mode="><span class="itemname">Sketchup.debug_mode=</span><span class="version">SketchUp 2016+</span></dt>
<dd>
<p>
 The debug_mode= method lets you controls whether SketchUp will output
 warnings to the console when it detects incorrect usage of the API.
 The setting takes effect right away, no need to restart SketchUp.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">enabled</dt>
<dd>If true, SketchUp will produce debug warnings.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>setting</dt>
<dd>true if debug mode is enabled.</dd></dl>
<pre class="prettyprint">
 Sketchup.debug_mode = true</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="debug_mode?"><span class="itemname">Sketchup.debug_mode?</span><span class="version">SketchUp 2016+</span></dt>
<dd>
<p>
 The debug_mode? controls whether SketchUp will output warnings to the console
 when it detects incorrect usage of the API.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>debug_mode</dt>
<dd>true if debug mode is enabled</dd></dl>
<pre class="prettyprint">
 debug_mode = Sketchup.debug_mode?</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="display_name_from_action"><span class="itemname">Sketchup.display_name_from_action</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The display_name_from_action method is used to gets a user-friendly name
 from an action string. See Sketchup.send_action for a list of valid
 action strings.

<br/><br/> Note: This method has been non-functional on Mac since SketchUp 8.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">action_name</dt>
<dd>An action string.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt></dt>
<dd>              friendly_name = a friendly name.</dd></dl>
<pre class="prettyprint">
 Sketchup.display_name_from_action("viewRight:")</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="extensions"><span class="itemname">Sketchup.extensions</span><span class="version">SketchUp 8.0 M2+</span></dt>
<dd>
<p>
 Returns the <a href="extensionsmanager">ExtensionsManager</a> where you can find all registered
 <a href="sketchupextension">SketchupExtension</a> objects.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>extensionsmanager</dt>
<dd>an <a href="extensionsmanager">ExtensionsManager</a> object.</dd></dl>
<pre class="prettyprint">
 extensions = Sketchup.extensions
 for extension in extensions
   UI.messagebox('The next extension is named: ' + extension.name +
       ' and its loaded? state is: ' + extension.loaded?)
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="file_new"><span class="itemname">Sketchup.file_new</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The file_new method is used to create a new file.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>Sketchup</dt>
<dd>a Sketchup object if successful.</dd></dl>
<pre class="prettyprint">
 new_sketchup = Sketchup.file_new</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="find_support_file"><span class="itemname">Sketchup.find_support_file</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The find_support_files method is used to retrieve the relative path and name
 of a file within the SketchUp installation directory.

<br/><br/> Forward slashes must be used to delimit between directory names.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>Name of the filename you want to find.</dd></dl>
<dl class="param"><dt class="argname">directory</dt>
<dd>(optional) directory relative to the SketchUp installation directory.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>path</dt>
<dd>the entire path if successful. If unsuccessful,
                      the method returns false.</dd></dl>
<pre class="prettyprint">
 help_file = Sketchup.find_support_file "help.html", "Plugins/"
 if (help_file)
   # Print out the help_file full path
   UI.messagebox help_file

   # Open the help_file in a web browser
   UI.openURL "file://" + help_file
 else
   UI.messagebox "Failure"
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="find_support_files"><span class="itemname">Sketchup.find_support_files</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The find_support_files method is used to retrieve the path and name of all
 matching files within the SketchUp installation directory.

<br/><br/> Forward slashes must be used to delimit between directory names.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>Extension of the files to be found.</dd></dl>
<dl class="param"><dt class="argname">directory</dt>
<dd>directory relative to the SketchUp installation directory. Without this the result will be empty.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>array</dt>
<dd>an array of files. If unsuccessful, the method
                      returns false.</dd></dl>
<pre class="prettyprint">
 files = Sketchup.find_support_files('rb', 'Plugins')</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="fix_shadow_strings="><span class="itemname">Sketchup.fix_shadow_strings=</span><span class="version">SketchUp 8.0 M1+</span></dt>
<dd>
<p>
 The fix_shadow_strings= method lets you control whether shadow rendering
 attempts to fix an artifact commonly referred to as "strings".  The fix
 is actually very model dependent and not controllable from the UI, so this
 method can be used to control it.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">enabled</dt>
<dd>If true, shadow strings fix will be turned on. If false, it will be deactivated.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>setting</dt>
<dd>true if shadow strings fix was turned on.</dd></dl>
<pre class="prettyprint">
 Sketchup.fix_shadow_strings=true</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="fix_shadow_strings?"><span class="itemname">Sketchup.fix_shadow_strings?</span><span class="version">SketchUp 8.0 M1+</span></dt>
<dd>
<p>
 The fix_shadow_strings? method indicates whether the a fix for a shadow
 rendering artifact commonly referred to as "strings" is enabled.  The fix
 is actually very model dependent and not controllable from the UI, so this
 method can be used to test it.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>fix_shadow_strings</dt>
<dd>true if the feature is on.</dd></dl>
<pre class="prettyprint">
 is_on = Sketchup.fix_shadow_strings?</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="format_angle"><span class="itemname">Sketchup.format_angle</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The format_angle method takes a number as an angle in radians and formats it
 into degrees. For example, format_angle(Math::PI) will return 180.0.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">number</dt>
<dd>A number to be formatted.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>degrees</dt>
<dd>an angle in degrees if successful, false if
                      unsuccessful</dd></dl>
<pre class="prettyprint">
 degrees = Sketchup.format_angle Math::PI</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="format_area"><span class="itemname">Sketchup.format_area</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The format_area method formats a number as an area using the current units
 settings.

<br/><br/> The default unit setting is inches. For example, 10 becomes 10 inches
 squared.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">number</dt>
<dd>A number to be formatted.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>area</dt>
<dd>an area if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 area = Sketchup.format_area number</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="format_degrees"><span class="itemname">Sketchup.format_degrees</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The format_degrees method formats a number as an angle given in degrees. For
 example, 10 becomes 10.0. This is the equivalent to a to_f call.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">number</dt>
<dd>A number to be formatted.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>degrees</dt>
<dd>degrees if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 degrees = Sketchup.format_degrees number</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="format_length"><span class="itemname">Sketchup.format_length</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The format_length method formats a number as a length using the current
 units settings.

<br/><br/> The default unit setting is inches. For example, 10 becomes 10".</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">number</dt>
<dd>A number to be formatted.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>length</dt>
<dd>length if successful, false if unsuccessful</dd></dl>
<pre class="prettyprint">
 length = Sketchup.format_length 10
 if (length)
   UI.messagebox length
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="get_datfile_info"><span class="itemname">Sketchup.get_datfile_info</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The get_datfile_info method is used to retrieve the value for the given key
 from Sketchup.dat.

<br/><br/> If the key is not found, default_value is returned.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">key</dt>
<dd>The key whose value you want to retrieve.</dd></dl>
<dl class="param"><dt class="argname">default_value</dt>
<dd>The default value you want returned if key is not available.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>value</dt>
<dd>a string value if successful.</dd></dl>
<pre class="prettyprint">
 value = Sketchup.get_datfile_info(key, default_value)</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="get_i18ndatfile_info"><span class="itemname">Sketchup.get_i18ndatfile_info</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The get_i18ndatfile_info method is used to retrieve the value for the
 given key from the internationalization file that SketchUp uses to work
 in multiple languages.

<br/><br/> If the key is not found, default_value is returned.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">key</dt>
<dd>The key whose value you want to retrieve.</dd></dl>
<dl class="param"><dt class="argname">default_value</dt>
<dd>The default value you want returned if key is not available.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>value</dt>
<dd>a string value if successful.</dd></dl>
<pre class="prettyprint">
 value = Sketchup.get_i18ndatfile_info(key, default_value)</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="get_locale"><span class="itemname">Sketchup.get_locale</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The get_locale method returns the language code for the language SketchUp is
 running in.

<br/><br/> Valid return values include: en-US, fr, it, de, es, ja, ko, zh-CN, zh-TW,
                              pt-BR, nl, ru.
 If the OS language does not have corresponding folder and files in the
 SketchUp Resources folder, the returned language is, by default, en-US.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>language</dt>
<dd>a code representing the language SketchUp
                      is displaying.</dd></dl>
<pre class="prettyprint">
 locale = Sketchup.get_locale
 if (locale)
   UI.messagebox locale
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="get_resource_path"><span class="itemname">Sketchup.get_resource_path</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The get_resource_path is used to retrieve the directory where "resource"
 files are stored by SketchUp. Resource files include things like language
 localization files.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>The filename of a resource file in the resource directory hierarchy.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>path</dt>
<dd>the directory path to the resources folder.</dd></dl>
<pre class="prettyprint">
 directory = Sketchup.get_resource_path "Styles.strings"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="get_shortcuts"><span class="itemname">Sketchup.get_shortcuts</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The get_shortcuts method retrieves an array of all keyboard shortcuts
 currently registered with SketchUp. Each shortcut is returned as a
 string with the shortcut and the command separated by a tab, similar
 to "Ctrl+A\tEdit/Select All"</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>shortcuts</dt>
<dd>an array of shortcut strings.</dd></dl>
<pre class="prettyprint">
 shortcuts = Sketchup.get_shortcuts</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="install_from_archive"><span class="itemname">Sketchup.install_from_archive</span><span class="version">SketchUp 8.0 M2+</span></dt>
<dd>
<p>
 Installs the contents of a ZIP archive file into SketchUp's Plugins folder.
 If the ZIP contains subfolders, these will be preserved. This allows for a
 Ruby API plugin or Extension developer to distribute their plugin as a single
 file regardless of how many asset files must be included.

<br/><br/> The user will be shown a warning message that they must agree to before the
 install proceeds. If they do not agree, an Interrupt error will be raised.
 If the user does agree but there is a problem with the unzip process, an
 Exception will be raised. You can capture these states via a begin/rescue.
 See the example below.

<br/><br/> If the install is successful, any Ruby files that have been added to
 the Plugins folder will immediately be executed, saving the user a restart.

<br/><br/> To create an archive file, use your favorite tool (7zip, Winzip, etc.) to zip
 up any files and folders in your plugins directory. If the archive contains a
 <a href="sketchupextension">SketchupExtension</a> that you would like users to be able to install from the
 Preferences > Extensions panel, rename your file to have a .rbz file
 extension.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>extensionsmanager</dt>
<dd>an <a href="extensionsmanager">ExtensionsManager</a> object.</dd></dl>
<pre class="prettyprint">
 path = 'c:/temp/SomePluginPackage.zip'
 begin
   Sketchup.install_from_archive(path)
 rescue Interrupt => error
   UI.messagebox "User said 'no': " + error
 rescue Exception => error
   UI.messagebox "Error during unzip: " + error
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="is_64bit?"><span class="itemname">Sketchup.is_64bit?</span><span class="version">SketchUp 2015+</span></dt>
<dd>
<p>
 This methods indicates whether the host SketchUp application is 64bit.
 Useful for extensions that ship with binaries and need to determine
 which versions to load.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>Boolean</dt>
<dd>True if SketchUp is 64bit.</dd></dl>
<pre class="prettyprint">
 # For backward compatibility, check for the existence of the method
 # and load 32bit binaries for SketchUp versions that do not have this
 # method.
 if Sketchup.respond_to?(:is_64bit?) && Sketchup.is_64bit?
   # Load 64bit binaries.
 else
   # Load 32bit binaries.
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="is_online"><span class="itemname">Sketchup.is_online</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The is_online method is used to verify a connection to the Internet. This
 method can take some time to execute, so be careful not to call it more often
 than you need.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.is_online</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="is_pro?"><span class="itemname">Sketchup.is_pro?</span><span class="version">SketchUp 7.0+</span></dt>
<dd>
<p>
 Returns a boolean flag indicating whether the application is SketchUp Pro.
 Note that after the free trial period, SketchUp Pro will revert to regular
 SketchUp and this method will return false until the user registers
 the product.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>is_pro</dt>
<dd>true if the user is using SketchUp Pro</dd></dl>
<pre class="prettyprint">
 if (Sketchup.is_pro?)
   UI.messagebox "You are running SU Pro."
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="is_valid_filename?"><span class="itemname">Sketchup.is_valid_filename?</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The is_valid_filename? method is used to determine whether a filename
 contains illegal characters.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>A filename string.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if filename is valid, false if filename
                      is invalid (contains illegal characters).</dd></dl>
<pre class="prettyprint">
 status = Sketchup.is_valid_filename? filename</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="load"><span class="itemname">Sketchup.load</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The load method is used to include encrypted and nonencrypted ruby files.

<br/><br/> You do not need to include the file extension on the path. This method will
 look for .rb first (unencrypted) and then .rbe (encrypted) and finally .rbs
 (the deprecated scrambled format) files.
 See the "Distributing your Plugin" article for details.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">path</dt>
<dd>The path, including the filename, to the file you want to require.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>True if the file is included. False if the
                      file is not included.</dd></dl>
<pre class="prettyprint">
 sfile = "application_loader" # file extension not required
 status = Sketchup.load(sfile)</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="open_file"><span class="itemname">Sketchup.open_file</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The open_file method is used to open a file.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>The path and filename to open.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if opening the file succeeded,
                      false otherwise.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.open_file "C:\\model.skp"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="os_language"><span class="itemname">Sketchup.os_language</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The os_language method returns the language code for the language SketchUp
 is running in. This is an alias for the get_locale method.

<br/><br/> Valid return values are: en-US, fr, it, de, es, ja, ko, zh-CN, zh-TW,
 pt-BR, nl, ru.
 If the OS language does not have corresponding folder and files in the
 SketchUp Resources folder, the returned language is, by default, en-US.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>language</dt>
<dd>a code representing the language SketchUp
                      is displaying.</dd></dl>
<pre class="prettyprint">
 language = Sketchup.os_language</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="parse_length"><span class="itemname">Sketchup.parse_length</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The parse_length method parses a string as a length.

<br/><br/> For example, "200" becomes 200.0.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">string</dt>
<dd>The string to be parsed as a number.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>float</dt>
<dd>the numerical representation of the string if
                successful, or nil if unsuccessful.</dd></dl>
<pre class="prettyprint">
 float = Sketchup.parse_length("2'") # Returns 24 (representing inches)
 length = float.to_l # Convert to a Length type if needed.</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="platform"><span class="itemname">Sketchup.platform</span><span class="version">SketchUp 2014+</span></dt>
<dd>
<p>
 This methods returns a symbol indicating the current platform.

<br/><br/> It should be used over RUBY_PLATFORM as this returns a different value for
 Windows since SketchUp 2014.

<br/><br/> Older SketchUp versions still need to check
 <code>RUBY_PLATFORM.include?('mswin')</code> or
 <code>RUBY_PLATFORM.include?('darwin')</code>.

<br/><br/> Possible return values:
<ul>
<li>:platform_win</li>
<li>:platform_osx</li>
</ul></p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>symbol</dt>
<dd>Current OS platform.</dd></dl>
<pre class="prettyprint">
 IS_WIN = Sketchup.platform == :platform_win
 IS_OSX = Sketchup.platform == :platform_osx</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="plugins_disabled="><span class="itemname">Sketchup.plugins_disabled=</span><span class="version">SketchUp 8.0 M2+</span></dt>
<dd>
<p>
 The plugins_disabled= method lets you control whether SketchUp will load
 Ruby scripts from the plugins directory at startup time. This is primarily
 a trouble-shooting method. If you are having strange behavior in SketchUp
 that you suspect is from a bad script, you can type
 Sketchup.plugins_disabled=true into the Ruby console and restart SketchUp
 to see if the problem is fixed.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">enabled</dt>
<dd>If true, the plugins directory will not load.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>setting</dt>
<dd>true if plugins were disabled.</dd></dl>
<pre class="prettyprint">
 // Type this in the Ruby console then restart SketchUp.
 Sketchup.plugins_disabled=true

 // To reactivate plugins, type this into the Ruby console and restart.
 Sketchup.plugins_disabled=false</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="plugins_disabled?"><span class="itemname">Sketchup.plugins_disabled?</span><span class="version">SketchUp 8.0 M2+</span></dt>
<dd>
<p>
 The plugins_disabled? method indicates whether Ruby scripts in the plugins
 directory will be loaded at startup time.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>plugins_disabled</dt>
<dd>true if the plugins are disabled.</dd></dl>
<pre class="prettyprint">
 is_disabled = Sketchup.plugins_disabled?</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="quit"><span class="itemname">Sketchup.quit</span><span class="version">SketchUp 2014+</span></dt>
<dd>
<p>
 The quit method is used to terminate the application. This will pop-up the
 usual model save prompts if there are unsaved models open. User can cancel
 the model save, in which case the application will not terminate.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt></dt>
<dd>              self</dd></dl>
<pre class="prettyprint">
 Sketchup.quit
 # Do not expect code to execute reliably after this point.</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="read_default"><span class="itemname">Sketchup.read_default</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The read_default method is used to retrieve the string associated with a
 value within the specified sub-section section of a .INI file or registry
 (within the Software > SketchUp > SketchUp [Version] section).</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">section</dt>
<dd>A section in an .INI or registry.</dd></dl>
<dl class="param"><dt class="argname">variable</dt>
<dd>A variable within the section.</dd></dl>
<dl class="param"><dt class="argname">default</dt>
<dd>(optional) A default value if the value is not found.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>nil if unsuccessful, the value of the default
                      if successful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.read_default "section",
 "variable", "default"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="register_extension"><span class="itemname">Sketchup.register_extension</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The register_extension method is used to register an extension with
 SketchUp's extension manager (in SketchUp preferences).</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">extension</dt>
<dd>A <a href="sketchupextension">SketchupExtension</a> object.</dd></dl>
<dl class="param"><dt class="argname">load_on_start</dt>
<dd>Passing true into this will load the extension immediately and set it so that it will load automatically whenever SketchUp restarts.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if extension registered properly</dd></dl>
<pre class="prettyprint">
 utilitiesExtension = SketchupExtension.new "Utilities Tools",
   "Utilities/utilitiesTools.rb"

 utilitiesExtension.description = "Adds Tools->Utilities to the " +
   "SketchUp inteface. The Utilities submenu contains two tools: " +
   "Create Face and Query Tool."

 Sketchup.register_extension utilitiesExtension, false</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="register_importer"><span class="itemname">Sketchup.register_importer</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The register_importer method is used to register an importer with SketchUp.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">importer</dt>
<dd>An <a href="importer">Importer</a> object representing the importer.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.register_importer importer</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="remove_observer"><span class="itemname">Sketchup.remove_observer</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The remove_observer method is used to remove an observer from the current
 object.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">observer</dt>
<dd>An observer.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt></dt>
<dd>              true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.remove_observer observer</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="require"><span class="itemname">Sketchup.require</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The require method is used to include encrypted and nonencrypted ruby files.
 This is an alias of the Sketchup.load method.

<br/><br/> You do not need to include the file extension on the path. This method will
 look for .rb first (unencrypted) and then .rbe (encrypted) and finally .rbs
 (the deprecated scrambled format) files.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">path</dt>
<dd>The path, including the filename, to the file you want to require.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>True if the file is included. False if the
                      file is not included.</dd></dl>
<pre class="prettyprint">
 sfile = "application_loader" # file extension not required
 status = Sketchup::require(sfile)</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="save_thumbnail"><span class="itemname">Sketchup.save_thumbnail</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The save_thumbnail method is used to generate a thumbnail for any SKP file -
 not necessarily the loaded model.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">skp_filename</dt>
<dd>The name of the SketchUp file whose model you want represented in the thumbnail.</dd></dl>
<dl class="param"><dt class="argname">img_filename</dt>
<dd>The name of the file where the thumbnail will be saved.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.save_thumbnail "skp_filename", "image_filename"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="send_action"><span class="itemname">Sketchup.send_action</span><span class="version">SketchUp 6.0 (changes in SketchUp 8.0/2013)+</span></dt>
<dd>
<p>
 The send_action method sends a message to the message queue to perform some
 action asynchronously.

<br/><br/> Valid actions are:
<ul>
<li>showRubyPanel:</li>
<li>viewBack:</li>
<li>viewBottom:</li>
<li>viewFront:</li>
<li>viewIso:</li>
<li>viewLeft:</li>
<li>viewRight:</li>
<li>viewTop:</li>
<li>viewPerspective:</li>
<li>viewShowAxes:</li>
<li>viewShowHidden:</li>
<li>viewZoomExtents:</li>
<li>viewZoomToSelection:</li>
<li>viewUndo:</li>
<li>selectOrbitTool:</li>
<li>selectPositionCameraTool:</li>
<li>selectDollyTool:</li>
<li>selectTurnTool:</li>
<li>selectWalkTool:</li>
<li>selectZoomTool:</li>
<li>selectFieldOfViewTool:</li>
<li>selectZoomWindowTool:</li>
<li>pageAdd:</li>
<li>pageDelete:</li>
<li>pageUpdate:</li>
<li>pageNext:</li>
<li>pagePrevious:</li>
<li>renderWireframe:</li>
<li>renderHiddenLine:</li>
<li>renderMonochrome:</li>
<li>renderShaded:</li>
<li>renderTextures:</li>
<li>selectArcTool:</li>
<li>selectArc3PointTool:</li>
<li>selectArc3PointPieTool:</li>
<li>selectAxisTool:</li>
<li>selectCircleTool:</li>
<li>selectEraseTool:</li>
<li>selectFreehandTool:</li>
<li>selectLineTool:</li>
<li>selectMeasureTool:</li>
<li>selectMoveTool:</li>
<li>selectOffsetTool:</li>
<li>selectPaintTool:</li>
<li>selectPolygonTool:</li>
<li>selectProtractorTool:</li>
<li>selectPushPullTool:</li>
<li>selectRectangleTool:</li>
<li>selectRectangle3PointTool:</li>
<li>selectRotateTool:</li>
<li>selectScaleTool:</li>
<li>selectSectionPlaneTool:</li>
<li>selectTextTool:</li>
<li>selectDimensionTool:</li>
<li>selectExtrudeTool:</li>
<li>selectSelectionTool:</li>
<li>editUndo:</li>
<li>editRedo:</li>
<li>editHide:</li>
<li>editUnhide:</li>
<li>fixNonPlanarFaces:</li>
</ul>

<br/><br/> Added in SketchUp 8.0+:
<ul>
<li>addBuilding:</li>
<li>getPhotoTexture:</li>
<li>selectImageIglooTool:</li>
<li>selectNorthTool:</li>
</ul>

<br/><br/> Removed in SketchUp 2013+:
<ul>
<li>addBuilding:</li>
</ul>

<br/><br/> On the PC only, you can also send these numeric values. (Note that these are
 officially "unsupported" and are not guaranteed to work in current or
 future versions of the API.)

<br/><br/><ul>
<li>10501: set view to Top</li>
<li>10502: set view to Front</li>
<li>10503: set view to Rear</li>
<li>10504: set view to Left</li>
<li>10505: set view to Right</li>
<li>10506: set view to Bottom</li>
<li>10507: set view to Axonometric</li>
<li>10510: set render mode to Wire</li>
<li>10511: set render mode to Hidden lines removal</li>
<li>10512: set render mode to Surfaces Shading</li>
<li>10513: set render mode to Transparency</li>
<li>10519: set camera to ortho (removes perspective)</li>
<li>10520: walk tool</li>
<li>10521: display the System Preferences dialog box (Files tab)</li>
<li>10522: removes axes display</li>
<li>10523: pan tool</li>
<li>10525: set the interactive eye height feature</li>
<li>10526: zoom window</li>
<li>10527: zoom extents</li>
<li>10529: zoom out 2</li>
<li>10531: toggle the Standard toolbar</li>
<li>10532: toggle the <a href="camera">Camera</a> toolbar</li>
<li>10533: display the Shadows Settings dialog box</li>
<li>10537: toggle the Views toolbar</li>
<li>10538: display the System Preferences dialog box (Display tab)</li>
<li>10545: toggle <a href="color">Color</a> ByLayer</li>
<li>10546: toggle Shadows toolbar</li>
<li>10551: toogle Large icons</li>
<li>10576: toggle Render Mode toolbar</li>
<li>10596: set Render Mode to No Transparency (Preferences)</li>
<li>10597: set Render Mode to Wire (Preferences)</li>
<li>10598: set Render Mode to Transparency (Preferences)</li>
<li>10599: set Render Mode to Surfaces Shading (Preferences)</li>
<li>10600: set Render Mode to <a href="texture">Texture</a> (Preferences)</li>
<li>10601: set Render Mode to No <a href="texture">Texture</a> (Preferences)</li>
<li>10602: toggle Shadows</li>
<li>10603: toggle Profiles</li>
<li>10604: toggle Extension Lines</li>
<li>10605: toggle Jitter edges</li>
<li>21019: hide Status bar and VCB</li>
<li>21020: show Status bar and VCB</li>
<li>21022: hide Status bar and VCB</li>
<li>21023: place 3d text box</li>
<li>21024: select the Measure tool</li>
<li>21031: select the Freehand Draw tool</li>
<li>21041: select the PushPull tool</li>
<li>21048: select the Move tool</li>
<li>21052: hide selected objects</li>
<li>21056: create face with selected edges closed loop</li>
<li>21057: select the Protractor tool</li>
<li>21060: display Components Window</li>
<li>21061: toggle Draw toolbar</li>
<li>21063: toggle <a href="model">Model</a> Bounding Box display</li>
<li>21065: select the Arc tool</li>
<li>21067: creat a new <a href="page">Page</a></li>
<li>21069: select the Arc 3 Point tool</li>
<li>21070: select the Arc 3 Point Pie tool</li>
<li>21074: show the Materials Browser Window</li>
<li>21076: display the Preferences dialog box (<a href="text">Text</a> activated)</li>
<li>21077: display the Tip of the day Window</li>
<li>21078: select the Paint Bucket tool</li>
<li>21080: display the <a href="page">Page</a> Manager Window</li>
<li>21082: display the Macros Dialog Box</li>
<li>21086: display the Components Browser Window</li>
<li>21094: select the Rectangle tool</li>
<li>21095: select the Polygon tool</li>
<li>21096: select the Circle tool</li>
<li>21098: open the Open Window</li>
<li>21100: select the Offset tool</li>
<li>21101: slect all objects</li>
<li>21112: open the Import Window</li>
<li>21124: launch the validity check tool</li>
<li>21126: select the <a href="axes">Axes</a> tool</li>
<li>21029: select the Rotate tool</li>
<li>21032: toggle <a href="layer">Layer</a> toolbar</li>
<li>21036: display the Save as Window</li>
<li>21046: spin the model a full 360&deg; and display report</li>
<li>21047: fast Pick Time report</li>
<li>21049: open the Export model Window</li>
<li>21169: select the Position <a href="camera">Camera</a> tool</li>
<li>21170: display the Preferences, Tour Guide activated</li>
<li>21180: create a new <a href="page">Page</a> just right of selected page</li>
<li>21200: display the Insert <a href="image">Image</a> Window</li>
<li>21233: display Area of selected face</li>
<li>21234: display Area of all faces with selected material</li>
<li>21236: select the Scale tool</li>
<li>21237: display the Export 2D Graphics Window</li>
<li>21245: display a Polygon Offset Factors dialog box</li>
<li>21276: reverse selected face(s)</li>
<li>21287: select the Divide feature</li>
<li>21337: select the Section Plane Placement tool</li>
<li>21354: open the <a href="layer">Layer</a> Window</li>
<li>21386: open the Export <a href="animation">Animation</a> Window</li>
<li>21405: select the <a href="text">Text</a> tool</li>
<li>21406: display Fog dialog box</li>
<li>21410: select the Dim tool</li>
<li>21433: toggle Edit toolbar</li>
<li>21442: select the FollowMe tool</li>
<li>21448: select the <a href="axes">Axes</a> tool</li>
<li>21453: select all objects</li>
<li>21460: display Licence</li>
<li>21462: display Authorization dialog box</li>
<li>21463: display un-authorizing message</li>
<li>21464: display Open Licence files (Network) Window</li>
<li>21466: display Quick reference Card in Adobe Reader</li>
<li>21467: display Licences in use dialog box</li>
<li>21469: zoom extents to selected objects</li>
<li>21476: perform a non-planar check on selected objects</li>
<li>21477: list accelerators in window</li>
<li>21485: erase selected objects</li>
<li>21487: display Edit current material dialog box</li>
<li>21485: erase all new created pages</li>
<li>21488: display <a href="entity">Entity</a> Info Window</li>
<li>21490: display Soften Edges Window</li>
<li>21491: display Profiles</li>
<li>21492: display Extended Edges</li>
<li>21493: display Jitter Lines</li>
<li>21494: select Field of view tool</li>
<li>21513: display the outliner</li>
<li>21520: override Tile Rendering Size dialog box</li>
<li>21525: select the FollowMe tool</li>
<li>21542: display the Insert <a href="image">Image</a> Window</li>
<li>21560 and up: causes a runtime Error</li>
</ul></p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">action</dt>
<dd>The action to be performed.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if successful, false if unsuccessful</dd></dl>
<pre class="prettyprint">
 result = Sketchup.send_action "selectArcTool:"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="set_status_text"><span class="itemname">Sketchup.set_status_text</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The set_status_text method is used to
 set the text appearing on the status bar within the drawing window.

<br/><br/> If no arguments are passed, the status bar content is cleared. Valid
 positions are:

<br/><br/><ul>
<li>SB_PROMPT - the text will appear at the left-side of the status bar</li>
<li>SB_VCB_LABEL - the text will appear in place of the VCB label</li>
<li>SB_VCB_VALUE - the text will appear in the VCB</li>
</ul></p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">status</dt>
<dd>text (optional) the status text that will appear.</dd></dl>
<dl class="param"><dt class="argname">position</dt>
<dd>(optional) the position where the text will appear.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.set_status_text "This is a Test", SB_VCB_VALUE
 if (result)
   #code to do something if set_status_text is successful
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="status_text="><span class="itemname">Sketchup.status_text=</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The status_text= method is used to set the text appearing on the status
 bar within the drawing window.

<br/><br/> This is the same as calling set_status_text with a 2nd parameter of
 SB_PROMPT.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">status_text</dt>
<dd>The status text that will appear.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.status_text = "This is a Test"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="temp_dir"><span class="itemname">Sketchup.temp_dir</span><span class="version">SketchUp 2014+</span></dt>
<dd>
<p>
 The temp_dir method is used to retrieve the OS temporary directory for the
 current user. You can use this directory to write temporary files that are
 not required to persist between SketchUp sessions.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt></dt>
<dd>              <a href="string">String</a> containing the full temporary directory path</dd></dl>
<pre class="prettyprint">
 temp_dir = Sketchup.temp_dir</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="template"><span class="itemname">Sketchup.template</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The template method is used to get the file name of the current template.
 Templates are the .skp files that are loaded when the user select File > New.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>name</dt>
<dd>the current template</dd></dl>
<pre class="prettyprint">
 name = Sketchup.template</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="template="><span class="itemname">Sketchup.template=</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The template= method is used to set the file name of the current template.
 Templates are the .skp files that are loaded when the user select File > New.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">filename</dt>
<dd>The name of the template to set.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>status</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 status = Sketchup.template= "filename"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="template_dir"><span class="itemname">Sketchup.template_dir</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The template_dir is used to retrieve the directory where templates are
 stored by the SketchUp install. Templates are the .skp files that are loaded
 when the user select File > New.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt></dt>
<dd>              <a href="string">String</a> containing the full template directory path</dd></dl>
<pre class="prettyprint">
 directory = Sketchup.template_dir</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="undo"><span class="itemname">Sketchup.undo</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The undo method is used undo the last transaction on the undo stack.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>              nil</dt>
<dd></dd></dl>
<pre class="prettyprint">
 Sketchup.undo</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="vcb_label="><span class="itemname">Sketchup.vcb_label=</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The vcb_label= method is used to set the label that appears on the vcb,
 or the "value control box", which is another word for the "measurements"
 text entry box that appears at the bottom on the SketchUp window.

<br/><br/> This is the same as calling set_status_text with a 2nd parameter of
 SB_VCB_LABEL.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">label_text</dt>
<dd>The label text that will appear.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.vcb_label = "This is a Test"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="vcb_value="><span class="itemname">Sketchup.vcb_value=</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The vcb_value= method is used to set the value that appears on the vcb,
 or the "value control box", which is another word for the "measurements"
 text entry box that appears at the bottom on the SketchUp window.

<br/><br/> This is the same as calling set_status_text with a 2nd parameter of
 SB_VCB_VALUE.</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">value</dt>
<dd>The text that will appear as the vcb's value.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>true if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.vcb_value = "This is a Test"</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="version"><span class="itemname">Sketchup.version</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 Gets the current version of sketchup in decimal form.</p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>version</dt>
<dd>the decimal form of the version</dd></dl>
<pre class="prettyprint">
 version = Sketchup.version
 if (version)
   UI.messagebox version
 else
   return
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="version_number"><span class="itemname">Sketchup.version_number</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 Get the current version of sketchup as a whole number for comparisons. The
 number returned has the major, minor, and build values packed into an integer
 value as follows:
<ul>
<li>Major version = X</li>
<li>Minor version = Y</li>
<li>Build number = Z</li>
</ul>

<br/><br/> SketchUp 6.0 - SketchUp 2015
<ul>
<li>XXYYYZZZ</li>
</ul>

<br/><br/> SketchUp 2016+
<ul>
<li>XXYZZZZZZZ</li>
</ul></p>
<p class="subhead">Returns:</p>
<dl class="return"><dt>version</dt>
<dd>the whole number form of the version</dd></dl>
<pre class="prettyprint">
 if (15003000...15004000) === Sketchup.version_number
   puts "SketchUp 15.3"
 end
 if Sketchup.version_number >= 1600000000
   puts "New format"
 end</pre><br class="clear"/>
</dd></dl>
<div class="line"></div><dl class="apireference"> <dt id="write_default"><span class="itemname">Sketchup.write_default</span><span class="version">SketchUp 6.0+</span></dt>
<dd>
<p>
 The write_default method is used to set the string associated with a
 variable within the specified sub-section of a .plist file on the Mac
 or the registry on Windows (within the Software > SketchUp > SketchUp
 [Version] section).</p>
<p class="subhead">Arguments:</p>
<dl class="param"><dt class="argname">section</dt>
<dd>A section in a .plist file (Mac) or the registry (Windows).</dd></dl>
<dl class="param"><dt class="argname">variable</dt>
<dd>A variable within the section.</dd></dl>
<dl class="param"><dt class="argname">value</dt>
<dd>The value to store.</dd></dl>
<p class="subhead">Returns:</p>
<dl class="return"><dt>result</dt>
<dd>True if successful, false if unsuccessful.</dd></dl>
<pre class="prettyprint">
 result = Sketchup.write_default "section",
   "variable", "my_value"</pre><br class="clear"/>
</dd></dl>
<p class="post">&nbsp;&nbsp;</p>
</div>

        </div>
        
<div id="gc-content-footer">





</div>




      </div>

      </div>
      

      
      
      <div id="about"><center><a href="http://www.trimble.com/"><img alt="Trimble Home" src="http://www.sketchup.com/images/FooterTrimble.png"></a><br /><a href="http://www.trimble.com/corporate/about_trimble.aspx">About Trimble</a> - <a href="http://www.trimble.com/privacy.aspx">Privacy Policy</a> - <a href="http://support.google.com/sketchup/bin/request.py?customer=supro&contact_type=sales">Contact Us</a></center></div>
      
      
    </div>
    
    <script src="/intl/en/developer/assets/script_foot.js"></script>
    <script>
      (function($) {
        devsite.devsite.Init($, null, '');
      })(jQuery);

      
      devsite.localInit = function() {
        document.getElementById('quick-reference-nav').style.display = 'block';
      };
      
    </script>

    



<script type="text/javascript">
$(document).ready(function(e) {
    // Render any carousels on the page
    $('.carousel').carousel();
    // Render any feed widgets on the page
    
    $('.feed').rss();
    $('.feed-plain').rss();
    // Render any OSS widgets on the page.
    $('.oss').oss();
    });
</script>

<script type="text/javascript" defer="">


$(document).ready(function() {
    contentTimer.name = 'content';
    contentTimer.tick('ol');
    window.jstiming.report(contentTimer);

    // Boilerplate javascript to enable the plusone button
    var po = document.createElement('script'); po.type = 'text/javascript';
    po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js?onload=devsite_plusoneLoaded';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(po, s);
});
</script>




  

<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"d7657f89f1","applicationID":"1894794","transactionName":"YlYBZkFRVkoCUxUPXlscNkBaH1FXF1xOA18aVwZEVlxXSQZCTgJeVkBMXUZCXFYAHxINVEFQC0dDHkhREw==","queueTime":0,"applicationTime":2,"atts":"ThECEAlLRUQ=","errorBeacon":"bam.nr-data.net","agent":""}</script></body></html>
